export const greyColor = "#666666";
export const black = "#000000";
export const white = "#fff";

export const products = [
  {
    image: "bag.png",
    title: "The Marc Jacobs",
    desc: "Traveler Tote",
    price: "$195.00",
  },
  {
    image: "shoe.png",
    title: "Axel Arigato",
    desc: "Clean 90 Triple Sneakers",
    price: "$245.00",
  },
  ,
  {
    image: "shoe.png",
    title: "Axel Arigato",
    desc: "Clean 90 Triple Sneakers",
    price: "$245.00",
  },
  {
    image: "bag.png",
    title: "The Marc Jacobs",
    desc: "Traveler Tote",
    price: "$195.00",
  },
];
