import React from "react";
import Sidebar from "../Components/LeftPart";

const Settings=()=> {
  return <Sidebar>Settings</Sidebar>;
}

export default Settings;