import React from "react";
import Sidebar from "../Components/LeftPart";

const Reports=()=> {
  return <Sidebar>Reports</Sidebar>;
}

export default Reports;