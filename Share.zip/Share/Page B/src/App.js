import "./App.css";
import AllRoutes from "./Routes/AllRoutes";

const App=()=>{
  return (
    <div className="App">
      <AllRoutes />
    </div>
  );
}

export default App;
